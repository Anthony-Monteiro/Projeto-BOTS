<?php
// Verifica se a sessão não está definida
if (!isset($_SESSION)) {
  session_start();
}


?>