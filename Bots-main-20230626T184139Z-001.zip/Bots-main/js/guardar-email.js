

    function enviar(){
        var valor = document.getElementById("textinput").value;
        alert("Você digitou: " + valor);
    }
