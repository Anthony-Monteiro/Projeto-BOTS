const $html = document.querySelector('html')

function themeSwitch() {
    $html.classList.toggle('dark-mode')
}